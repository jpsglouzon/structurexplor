#ifndef SOURCETOOLS_COLLECTION_COLLECTION_H
#define SOURCETOOLS_COLLECTION_COLLECTION_H

#include <sourcetools/collection/Position.h>
#include <sourcetools/collection/Range.h>

#endif /* SOURCETOOLS_COLLECTION_COLLECTION_H */
